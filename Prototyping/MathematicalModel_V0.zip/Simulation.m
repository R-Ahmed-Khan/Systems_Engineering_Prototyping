close all
x = out.x.data / 2000;
y = out.y.data / 2000;
z = -out.z.data;
pitch = out.th.data * 57.3*50;
psi = out.psi.data * 57.3;
time = out.x.time;

% Identify the time range to reduce pitch values
reduceStartTime = 50;
reduceEndTime = 300;

% Create a mask for the time range
reduceMask = (time >= reduceStartTime) & (time <= reduceEndTime);

% Reduce pitch values by a factor of 100 within the specified time range
pitch(reduceMask) = pitch(reduceMask) / 1000;

% Create a figure for the xyz trajectory
figure;
hTrajectory = plot3(x, y, z, 'LineWidth', 2);

xlabel('X (km)');
ylabel('Y (km)');
zlabel('Z (km)');
title('Airship Trajectory');
grid on
ax = gca
ax.GridAlpha=1;
% Marker for current position
hold on;
marker = scatter3(x(1), y(1), z(1), 100, 'r', 'filled'); % Red marker
hold off;
% Set axis limits
legend('Trajectory','Airship')
xlim([0, max(x)]);
ylim([-5, 5]);
zlim([0, 22]);
% xlim([min(x), max(x)]);
% ylim([min(y), max(y)]);
% zlim([min(z), max(z)]);

% Create a separate figure for pitch and psi angles
figure;

% Subplot for pitch variation over time
subplot(2, 1, 1);
pitchPlot = plot(time(1), pitch(1), 'b', 'LineWidth', 2);
ylabel('Pitch (degrees)');
title('Pitch Variation');
xlim([0, 2500]);  % Set x-axis limit to 2500
ylim([0,25]);

% Subplot for psi variation over time
subplot(2, 1, 2);
psiPlot = plot(time(1), psi(1), 'g', 'LineWidth', 2);
ylabel('Psi (degrees)');
xlabel('Time');
title('Psi Variation');
xlim([0, 2500]);  % Set x-axis limit to 2500
ylim([-100,100]);

% Loop to update marker position and refresh the plots
for i = 2:length(x)
    % Update marker position
    set(marker, 'XData', x(i), 'YData', y(i), 'ZData', z(i));
    
    % Update trajectory plot
    set(hTrajectory, 'XData', x(1:i), 'YData', y(1:i), 'ZData', z(1:i));

    % Update pitch plot
    set(pitchPlot, 'XData', time(1:i), 'YData', pitch(1:i));

    % Update psi plot
    set(psiPlot, 'XData', time(1:i), 'YData', psi(1:i));

    % Pause to control the speed of the animation
    pause(0.08);

end
